$( function() {
    $( "#accordion" ).accordion();
  } );
  


